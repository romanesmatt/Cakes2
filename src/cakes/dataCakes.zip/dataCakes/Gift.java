package cakes.dataCakes;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Gift implements Serializable{}